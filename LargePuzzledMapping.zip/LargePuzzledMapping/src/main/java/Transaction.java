public class Transaction {
    public String transactionId;
    public String fromAddress;
    public String toAddress;
    public float amount;
    public long timestamp;
    public long expiryTime;
    public boolean fromApproved = false;
    public boolean toApproved = false;

    public Transaction(String fromAddress, String toAddress, float amount) {
        this.fromAddress = fromAddress;
        this.toAddress = toAddress;
        this.amount = amount;
        this.timestamp = System.currentTimeMillis();
        this.expiryTime = this.timestamp + (60 * 1000);
        this.transactionId = fromAddress + "->" + toAddress + "@" + timestamp;
    }

    public boolean isExpired() {
        return System.currentTimeMillis() > expiryTime;
    }
}