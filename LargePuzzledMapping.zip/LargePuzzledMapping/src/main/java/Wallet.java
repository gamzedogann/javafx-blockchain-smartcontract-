public class Wallet {
    public String address;
    public float balance;
    public int transactionCount = 0;
    public boolean blacklisted = false;

    public Wallet(String address, float initialBalance) {
        this.address = address;
        this.balance = initialBalance;
    }

    public void addBalance(float amount) {
        this.balance += amount;
    }

    public void subtractBalance(float amount) {
        this.balance -= amount;
    }

    public void incrementTransactionCount() {
        this.transactionCount++;
    }

    public void resetTransactionCount() {
        this.transactionCount = 0;
    }

    public void setBlacklisted(boolean status) {
        this.blacklisted = status;
    }

    public boolean isBlacklisted() {
        return this.blacklisted;
    }
}