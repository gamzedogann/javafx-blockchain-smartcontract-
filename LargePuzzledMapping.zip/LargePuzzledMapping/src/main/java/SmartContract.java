import java.util.*;

public class SmartContract {
    public List<Transaction> pendingTransactions = new ArrayList<>();
    public Map<String, Wallet> wallets = new HashMap<>();

    public void createWallet(String address, float balance) {
        wallets.put(address, new Wallet(address, balance));
    }

    public void submitTransaction(Transaction tx) {
        Wallet sender = wallets.get(tx.fromAddress);

        if (sender == null || sender.isBlacklisted()) {
            System.out.println("[X] İşlem reddedildi: Kara listedeki cüzdan.");
            return;
        }

        if (sender.transactionCount >= 5) {
            sender.setBlacklisted(true);
            System.out.println("[X] İşlem sınırı aşıldı. Cüzdan kara listeye alındı.");
            return;
        }

        if (sender.balance < tx.amount) {
            System.out.println("[X] Yetersiz bakiye.");
            return;
        }

        pendingTransactions.add(tx);
        sender.incrementTransactionCount();
        System.out.println("[✓] İşlem eklendi: " + tx.transactionId);
    }

    public void approveTransaction(String walletAddress, String transactionId) {
        for (Transaction tx : pendingTransactions) {
            if (tx.transactionId.equals(transactionId)) {
                if (tx.fromAddress.equals(walletAddress)) {
                    tx.fromApproved = true;
                    System.out.println("[→] Gönderen onayı verildi.");
                } else if (tx.toAddress.equals(walletAddress)) {
                    tx.toApproved = true;
                    System.out.println("[→] Alıcı onayı verildi.");
                }

                if (tx.fromApproved && tx.toApproved && !tx.isExpired()) {
                    wallets.get(tx.fromAddress).subtractBalance(tx.amount);
                    wallets.get(tx.toAddress).addBalance(tx.amount);
                    System.out.println("[✓] İşlem blok haline geldi: " + tx.transactionId);
                    pendingTransactions.remove(tx);
                }
                return;
            }
        }
        System.out.println("[!] İşlem bulunamadı.");
    }

    public void audit() {
        for (Wallet w : wallets.values()) {
            if (w.isBlacklisted()) {
                System.out.println("[AUDIT] Kara listedeki cüzdan: " + w.address);
            }
        }
    }

    public void resetBlacklist(String walletAddress) {
        Wallet w = wallets.get(walletAddress);
        if (w != null && w.isBlacklisted()) {
            w.setBlacklisted(false);
            w.resetTransactionCount();
            System.out.println("[✓] Kara liste kaldırıldı: " + walletAddress);
        }
    }
}