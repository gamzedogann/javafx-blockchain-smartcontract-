public class Main {
    public static void main(String[] args) {
        SmartContract contract = new SmartContract();

        contract.createWallet("admin", 1000);
        contract.createWallet("kullanici1", 100);
        contract.createWallet("kullanici2", 50);

        Transaction tx1 = new Transaction("admin", "kullanici1", 100);
        contract.submitTransaction(tx1);

        System.out.println("--- Onaylar başlamadan bekleyen işlemler ---");
        contract.pendingTransactions.forEach(t -> System.out.println(t.transactionId));

        contract.approveTransaction("admin", tx1.transactionId);
        contract.approveTransaction("kullanici1", tx1.transactionId);

        System.out.println("--- Yeni işlem: kara liste testi ---");
        for (int i = 0; i < 6; i++) {
            Transaction spamTx = new Transaction("kullanici1", "kullanici2", 1);
            contract.submitTransaction(spamTx);
        }

        System.out.println("--- Audit logu ---");
        contract.audit();

        contract.resetBlacklist("kullanici1");

        Transaction tx2 = new Transaction("kullanici1", "kullanici2", 5);
        contract.submitTransaction(tx2);
        contract.approveTransaction("kullanici1", tx2.transactionId);
        contract.approveTransaction("kullanici2", tx2.transactionId);
    }
}